//
//  TP3.hpp
//  TP1 Base programation
//
//  Created by Mérové on 08/10/2021.
//

#ifndef TP3_hpp
#define TP3_hpp

#include <stdio.h>

class TP3{
    public:
    void exercice1();
    void exercice2();
    void exercice3();
    void exercice41();
    void exercice42();
    
    
    
};
    
    
#endif /* TP3_hpp */
