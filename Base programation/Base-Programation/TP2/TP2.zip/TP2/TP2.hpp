//
//  TP2.hpp
//  TP1 Base programation
//
//  Created by Mérové on 29/09/2021.
//

#ifndef TP2_hpp
#define TP2_hpp

#include <stdio.h>
class TP2{
    public:
        void exercice1();
        void exercice2(int a);
        void exercice3();
        void exercice4();
        void exercice5();
        void exercice6();
        void exercice7();
        void exercice8();
        void exercice9();
    
};

#endif /* TP2_hpp */
